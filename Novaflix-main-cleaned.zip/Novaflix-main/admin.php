<?php
// On prolonge la session
session_start();

// On teste si la variable de session existe et contient une valeur
if (empty($_SESSION['email'])) {
    // Si inexistante ou nulle, on redirige vers le formulaire de login
    exit();
}
else{
    // FECTH data || from DATABASE
    require('src/connect.php');
    $profilesDB = $db->query('SELECT * FROM profile order by email asc');
    $usersDB = $db->query('SELECT * FROM user');
    $commentsDB = $db->query('SELECT * FROM comments');

    if($_SESSION['role']  === "membre"){
        
        exit();
    }

}
include "api/info.php";
?>

<!DOCTYPE html>
    <link href="styles/styles_home.css" rel="stylesheet">
<body>

    <!-----------------------------------------------------------------------
------------------------------------------------------------------------->
    <?php
    ?>

    <!-----------------------------------------------------------------------
                     WEBSITE
------------------------------------------------------------------------->
    <div class="container_page">
    
<!-- ======================================================================
        //======================================================================-->

            <?php 
            <div class="col text-center">
            </div>
            <div class="col text-center">
            </div>
            <?php endif ?>
            <div class="col text-center">
            </div>
        </div>

            <!-- ======================================================================
        //======================================================================-->
            <table class="table table-striped my-3 text-center align-items-center">
                        <tr>
                            <th>ID comment</th>
                            <th>Film/Serie</th>
                            <th>ID | Nom du film</th>
                            <th>ID | Pseudo</th>
                            <th colspan="50%">Commentaire</th>
                            <th>Date</th>
                            <th>Éditer</th>
                            <th>Supprimer</th>
                        </tr>
                    <tbody">
                        <?php while($comment = $commentsDB->fetch()) {?>
                        <tr>
                            <th scope="row"><?php echo $comment['id']; ?></th>
                            <td><?php echo $comment['film_serie']; ?></td>
                            <td><?php echo $comment['id_film']." | ". $comment['nom_film']; ?></td>
                            <td><?php echo $comment['id_pseudo']." | ". $comment['pseudo']; ?></td>
                            <td colspan="50%"><?php echo $comment['commentaires']; ?></td>
                            <td><?php echo $comment['date']; ?></td>
                            <td>
                                <i class="fa fa-edit fa-xl text-warning" 
                                data-toggle="modal" 
                                data-target="#editComment<?php echo $comment['id']; ?>"> 
                                </i>
                                
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-body bg-dark">
                                                        <div class="form-group">
                                                            <?php $profilesPseudo = $db->query('SELECT pseudo, email, id_pseudo FROM profile');?>
                                                            <label for="id_pseudo" class="col-form-label">Pseudo</label><br>
                                                            <select class="form-control validate text-center"  name="id_pseudo">
                                                                <option value="" disabled selected>Select a profile pseudo...</option>
                                                                <?php foreach ($profilesPseudo as $profilePseudo) :?>
                                                                <option  value="<?php echo $profilePseudo['id_pseudo'] ?>" <?php if($profilePseudo['id_pseudo'] ==  $comment['id_pseudo']) {echo "selected";} ?>><?php echo $profilePseudo['pseudo']." | ID: ".$profilePseudo['id_pseudo']." | ". $profilePseudo['email'] ?></option>
                                                                <?php endforeach ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="comment" class="col-form-label">Comment</label>
                                                            <textarea type="text" class="form-control text-center" name="comment"><?php echo $comment['commentaires']; ?></textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="date" class="col-form-label">Date</label>
                                                            <input type="date" class="form-control text-center" name="date" value="<?php echo $comment['date'];?>">
                                                        </div>

                                                        <input type="hidden"  name="dbName" value="comments">
                                                        <input type="hidden" name="originalID" value="<?php echo $comment['id'];?>">

                                                    
                                                        <div class="modal-footer justify-content-center ">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                            <button type="submit" class="btn btn-success">Valider</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                
                            </td>
                            <td>
                                <i class="fa fa-trash fa-xl text-danger" 
                                data-toggle="modal" 
                                data-target="#deleteComment<?php echo $comment['id']; ?>"> 
                                </i>
                                
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-body bg-dark">
                                                    <p>Êtes-vous sûr de vouloir supprimer l'<strong>ID <?php echo $comment['id'];?></strong> ? </p>
                                                    <div class="modal-footer justify-content-center ">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                        <button class="btn btn-danger" type="button">Supprimer</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                
                            </td>
                        </tr>
                        <?php }; ?>
                    </tbody>
                    <tfoot>
                        <th class="text-center" colspan="100%">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-body bg-dark">
                                                <div class="form-group">
                                                    <label for="filmID" class="col-form-label">Film/Serie ID</label>
                                                    <input type="number" class="form-control text-center" name="filmID" value="<?php echo $comment['id_film'];?>">
                                                </div>
                                                <div class="form-group">
                                                        <?php $takeProfilesPseudo = $db->query('SELECT pseudo, email, id_pseudo FROM profile');?>
                                                        <label for="pseudo" class="col-form-label">Profile Pseudo</label><br>
                                                        <select class="form-control validate text-center"  name="pseudo">
                                                            <option value="" disabled selected>Select a profile pseudo...</option>
                                                            <?php foreach ($takeProfilesPseudo as $takeProfilePseudo) :?>
                                                            <option  value="<?php echo $takeProfilePseudo['pseudo'] ?>"><?php echo $takeProfilePseudo['pseudo']." || from ". $takeProfilePseudo['email'] ?></option>
                                                            <?php endforeach ?>
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="comment" class="col-form-label">Comment</label>
                                                    <textarea type="text" class="form-control text-center" name="comment" placeholder="type a message here..."></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label for="date" class="col-form-label">Date</label>
                                                    <input type="date" class="form-control text-center" name="date"  value="<?= date('Y-m-d'); ?>" max="<?= date('Y-m-d'); ?>">
                                                </div>
                                                <input type="hidden"  name="dbName" value="comments">
                                                    
                                                <div class="modal-footer justify-content-center ">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                    <button type="submit" class="btn btn-success">Valider</button>
                                                    </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </th>
                    </tfoot>
            </table>
        </div>


<!-- ======================================================================
        //======================================================================-->
        
            <table class="table table-striped my-3 text-center align-items-center">
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Rôle</th>
                        <th>Éditer</th>
                        <th>Supprimer</th>
                    </tr>
                <tbody">
                    <?php while($user = $usersDB->fetch()) {?>
                    <tr>
                        <th scope="row"><?php echo $user['id']; ?></th>
                        <td><?php echo $user['email']; ?></td>
                        <td>
                            <i class="fa fa-edit fa-xl text-warning" 
                            data-toggle="modal" 
                            data-target="#edit<?php echo $user['id']; ?>"> 
                            </i>
                            
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-body bg-dark">
                                                    <div class="form-group">
                                                        <label for="userID" class="col-form-label">User ID</label>
                                                        <input type="number" class="form-control text-center" name="userID"  value="<?php echo $user['id'];?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="userMail" class="col-form-label">User Mail</label>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="role" class="col-form-label">User Role</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label" for="role1">Membre</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label" for="role2">Modérateur</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                    </div>
                                                    <input type="hidden" name="dbName" value="user">
                                                    <input type="hidden" name="userOriginalID" value="<?php echo $user['id'];?>">
                                                
                                                    <div class="modal-footer justify-content-center ">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                        <button type="submit" class="btn btn-success">Valider</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            
                        </td>
                        <td>
                            <i class="fa fa-trash fa-xl text-danger" 
                            data-toggle="modal" 
                            data-target="#deleteUser<?php echo $user['id']; ?>"> 
                            </i>
                            
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-body bg-dark">
                                                <p>Êtes-vous sûr de vouloir supprimer l'<strong>ID <?php echo $user['id'];?></strong> ? </p>
                                                <div class="modal-footer justify-content-center ">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                    <button class="btn btn-danger" type="button">Supprimer</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            
                        </td>
                    </tr>
                    <?php }; ?>
                </tbody>
                <tfoot>
                    <th class="text-center" colspan="100%">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-body bg-dark">
                                                <div class="form-group">
                                                    <label for="password" class="col-form-label">User Mail</label>
                                                </div>
                                                <div class="form-group">
                                                    <label for="userMail" class="col-form-label">User Password</label>
                                                    <input type="password" class="form-control validate text-center" name="password" placeholder="type a password here...">
                                                </div>
                                                <div class="form-group">
                                                    <label for="role" class="col-form-label">User Role</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label" for="role1">Membre</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label" for="role2">Modérateur</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                </div>
                                                <input type="hidden" id="dbName" name="dbName" value="user">
                                                
                                                <div class="modal-footer justify-content-center ">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                    <button type="submit" class="btn btn-success">Valider</button>
                                                    </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </th>
                </tfoot>
            </table>
        </div>
        <?php endif ?>


<!-- ======================================================================
        //======================================================================-->
       
        <table class="table table-striped my-3 text-center align-items-center">
                    <tr>
                        <th>ID profil</th>
                        <th>Pseudo</th>
                        <th>Catégorie</th>
                        <th>Email</th>
                        <th>Image</th>
                        <th>Éditer</th>
                        <th>Supprimer</th>
                    </tr>
                <tbody">
                    <?php while($profile = $profilesDB->fetch()) {?>
                    <tr>
                        <th scope="row"><?php echo $profile['id_pseudo']; ?></th>
                        <td><?php echo $profile['pseudo']; ?></td>
                        <td><?php echo $profile['categorie']; ?></td>
                        <td><?php echo $profile['email']; ?></td>
                        <td><?php echo $profile['image']; ?></td>
                        <td>
                            <i class="fa fa-edit fa-xl text-warning" 
                            data-toggle="modal" 
                            data-target="#editProfile<?php echo $profile['id_pseudo']; ?>"> 
                            </i>
                            
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-body bg-dark">
                                                    <div class="form-group">
                                                        <label for="profileID" class="col-form-label">Profile ID</label>
                                                        <input type="number" class="form-control text-center" name="profileID" value="<?php echo $profile['id_pseudo'];?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="profilePseudo" class="col-form-label">Pseudo</label>
                                                        <input type="text" class="form-control text-center" name="profilePseudo"  value="<?php echo $profile['pseudo'];?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="userMail" class="col-form-label">User Mail</label>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="profileImage" class="col-form-label">Profile Image</label>
                                                        <input type="text" class="form-control text-center" name="profileImage"  value="<?php echo $profile['image'];?>">
                                                    </div>
                                                    <p>Catégorie</p>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label" for="categorie1">Enfant</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                    </div>

                                                    <input type="hidden" name="dbName" value="profile">
                                                    <input type="hidden" name="profileOriginalID" value="<?php echo $profile['id_pseudo'];?>">
                                                    <input type="hidden"  name="profileOriginalEmail" value="<?php echo $profile['email'];?>">

                                                
                                                    <div class="modal-footer justify-content-center ">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                        <button type="submit" class="btn btn-success">Valider</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            
                        </td>
                        <td>
                            <i class="fa fa-trash fa-xl text-danger" 
                            data-toggle="modal" 
                            data-target="#deleteProfile<?php echo $profile['id_pseudo']; ?>"> 
                            </i>
                            
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-body bg-dark">
                                                <p>Êtes-vous sûr de vouloir supprimer l'<strong>ID <?php echo $profile['id_pseudo'];?></strong> ? </p>
                                                <div class="modal-footer justify-content-center ">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                    <button class="btn btn-danger" type="button">Supprimer</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            
                        </td>
                    </tr>
                    <?php }; ?>
                </tbody>
                <tfoot>
                    <th class="text-center" colspan="100%">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-body bg-dark">
                                                <div class="form-group">
                                                    <?php $takeUsersMail = $db->query('SELECT email FROM user');?>
                                                        <label for="mail" class="col-form-label">User Mail</label><br>
                                                        <select class="form-control validate text-center" id="mail" name="mail">
                                                            <option value="" disabled selected>Select an user email...</option>
                                                            <?php foreach ($takeUsersMail as $takeUserMail) :?>
                                                            <option  value="<?php echo $takeUserMail['email'] ?>"><?php echo $takeUserMail['email'] ?></option>
                                                            <?php endforeach ?>
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                        <label for="profilePseudo" class="col-form-label">Pseudo</label>
                                                        <input type="text" class="form-control text-center" name="profilePseudo"  placeholder="type a pseudo here...">
                                                    </div>
                                                <div class="form-group">
                                                        <label for="profileImage" class="col-form-label">Profile Image</label>
                                                        <input type="text" class="form-control text-center" name="profileImage" value="../images/user_pic/4.png">
                                                </div>
                                                <p>Catégorie</p>
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label" for="categorie1">Enfant</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                </div>
                                                <input type="hidden" name="dbName" value="profile">
                                                
                                                <div class="modal-footer justify-content-center ">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                    <button type="submit" class="btn btn-success">Valider</button>
                                                    </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </th>
                </tfoot>
            </table>
        </div>
        <?php endif ?>                                                                

    </div>
    <!-----------------------------------------------------------------------
                     FOOTER
------------------------------------------------------------------------->    
    <?php
    include "src/footer.php";
    ?>



    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter&display=swap');
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.4.5/swiper-bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>

</html>