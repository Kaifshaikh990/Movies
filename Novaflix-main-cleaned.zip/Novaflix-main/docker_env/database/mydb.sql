CREATE DATABASE IF NOT EXISTS mydb;
USE mydb;

CREATE TABLE Persons (
	PersonID int,
	LastName varchar(255),
	FirstName varchar(255)
);
