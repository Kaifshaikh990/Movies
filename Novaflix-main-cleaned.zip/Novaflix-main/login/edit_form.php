<?php
// On prolonge la session
session_start();
$userEmail = $_SESSION['email'];

// On teste si la variable de session existe et contient une valeur
if (empty($_SESSION['email'])) {
    // Si inexistante ou nulle, on redirige vers le formulaire de login
    exit();
}

$id = $_GET['id_pseudo'];

if (!empty($_GET['id_pseudo'])) {
    // Connexion à la base de données
    require('../src/connect.php');
    $requete = $db->query("SELECT id_pseudo, pseudo, categorie, email, image FROM profile WHERE id_pseudo='$id'");
    $infosProfil = $requete->fetch();


    //--------- MISE À JOURS DES INFORMATIONS DE LA BDD ---------//

    if (!empty($_POST['pseudo'])) {
        include('../src/connect.php');

        // On reprend les variables du form
        $pseudo = htmlspecialchars($_POST['pseudo']);
        $categorie = htmlspecialchars($_POST['categorie']);
        $image = htmlspecialchars($_POST['imageProfile']);

        // Modification de la base de données

        $updateProfil = "UPDATE profile SET pseudo='$pseudo', categorie='$categorie', image='$image' WHERE id_pseudo='$id'";
        $updateExecution = $db->exec($updateProfil);

        // // Mise à jour des informations
        // $requete = $db->query("SELECT id_pseudo, pseudo, categorie, email, image FROM profile WHERE id_pseudo='$id'");
        // $infosProfil = $requete->fetch();



    }
}

?>
<!DOCTYPE html>

    <title>NOVA · Edit your profile</title>
    <link href="styles/profil_select.css" rel="stylesheet">

<body>
    <div class="container1">

        <h1>Update your profile information</h1>

        <div id="container_form_edit">

            <div class="choose_your_image">
                <img src="<?php echo $infosProfil['image']; ?>" id="changeThis" alt="Profile's image" srcset="">
            </div>

            <form action='' method="post" id="form_profil">
                <select class="form-select" name="categorie" required>
                    <option value="" disabled selected hidden> Select your option</option>
                                                echo "selected";
                    <option value="enfant" <?php if ($infosProfil['categorie'] == 'enfant') {
                                                echo "selected";
                                            } ?>>Enfant</option>
                </select>

                <button type="submit" name="RegisterEnter" id="subButton">Submit</button>

            </form>

        </div>

        <a class="" href="profil_delete.php?id_pseudo=<?php echo $infosProfil['id_pseudo'] ?>&email=<?php echo $infosProfil['email'] ?>" style="">
             <button id="delButton">
                <div class="svg_white_delete">
                    <img class="X_WHITE" src="../images/X.svg" alt="delete your profile">
                </div>
                <div class="svg_red_delete">
                    <img class="X_RED" src='../images/X_red.svg' alt="delete your profile">
                </div>
             </button>
        </a>    


        <div id="container_form_images">

            <form action='' method="post" id="containerImages">

                <div class="row_images">
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="4">
                    </label>
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="2">
                    </label>
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="3">
                    </label>
                </div>

                <div class="row_images">
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="10">
                    </label>
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="5">
                    </label>
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="6">
                    </label>
                </div>

                <div class="row_images">
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="7">
                    </label>
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="12">
                    </label>
                                                                                                        echo "checked";
                                                                                                    } ?>>
                    <label for="11">
                    </label>
                </div>

            </form>

        </div>





    </div>
    <div class="arrowBack" onclick="location.href='profil_select.php' ">
             <svg version="1.1" id="Calque_1"  x="0px" y="0px"
             	 width="97.4px" height="97.7px" viewBox="0 0 97.4 97.7" style="enable-background:new 0 0 97.4 97.7;" xml:space="preserve">
                <style type="text/css">
                    .st0{fill-rule:evenodd;clip-rule:evenodd;fill:#FFFFFF;}
                </style>
                <path class="st0" d="M54.7,74.1c0.7,0.7,1.7,0.7,2.4,0l2.4-2.4c0.7-0.7,0.7-1.7,0-2.4L39.3,49l20.3-20.3c0.7-0.7,0.7-1.7,0-2.4
                    l-2.4-2.4c-0.7-0.7-1.7-0.7-2.4,0L30.8,47.7c-0.7,0.7-0.7,1.7,0,2.4L54.7,74.1z"/>
             </svg>
 	</div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="script/script_edit_form.js"></script>

</html>