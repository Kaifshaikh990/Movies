<?php
   // DATABASE - FREESQLDATABASE
   // $db = new PDO('mysql:host=sql11.freesqldatabase.com;dbname=sql11511523;charset=utf8', 'sql11511523', 'i2i73lwhkk');

   // DATABASE - AMAZON

?>
