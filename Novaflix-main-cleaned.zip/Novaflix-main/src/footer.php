<footer class="footer">
    <div class="footer_div">
        <img class="logo_bottom" src="images/logo.svg" alt="logo">
    </div>
    <div>
        <img class="logo_resp_bottom" src="images/logo_planete_resp.svg" alt="logo">
    </div>
    <div class="span_div">
        <span class="span_footer">SCI-FI STREAMING SOLUTION</span>
        <span class="span_footer">CREDITS & COOKIES</span>
        <span class="span_footer">NOVA 2022©</span>
        <span class="span_footer">ACCESSIBILITY</span>
        <span class="span_footer">REPORT A BUG</span>
    </div>
</footer>